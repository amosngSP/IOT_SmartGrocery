import requests
import datetime
from api import Database, website
from bothandler import BotHandler

db = Database()
iot_bot = BotHandler()

def subscribe(chatid):
    sql = "SELECT * FROM subscribe WHERE chat_id = '{}'".format(chatid)
    entry = db.select_one_row(sql)
    if entry:
        #user in database
        subscribe = entry[2]
        if subscribe == 1:
            return "Already Subscribed!"
        else:
            sql = "UPDATE `subscribe` SET `subscribe` = '1' WHERE (`id` = '{}');".format(entry[0])
            db.insert_update(sql)
            return "Status changed to subscribed!"
            
    else:
        sql = "INSERT INTO `subscribe` (`chat_id`, `subscribe`) VALUES ('{}', '1');".format(chatid)
        db.insert_update(sql)
        return "Added to the subscriber list!"
        
    
def unsubscribe(chatid):
    sql = "SELECT * FROM subscribe WHERE chat_id = '{}'".format(chatid)
    entry = db.select_one_row(sql)
    if entry:
        #user in database
        subscribe = entry[2]
        if subscribe == 0:
            return "Already Not Subscribed!"
        else:
            sql = "UPDATE `subscribe` SET `subscribe` = '0' WHERE (`id` = '{}');".format(entry[0])
            db.insert_update(sql)
            return "Status changed to unsubscribed!"
    else:
        return "You have not subscribed before!"
    
def main():
    new_offset = 0
    print("Telegram bot launching...")
    while True:
        all_updates=iot_bot.get_updates(new_offset)
        
        if len(all_updates) > 0:
            for current_update in all_updates:
                first_update_id = current_update['update_id']
                if 'text' not in current_update['message']:
                    first_chat_text='New member'
                else:
                    first_chat_text = current_update['message']['text']
                first_chat_id = current_update['message']['chat']['id']
                if 'first_name' in current_update['message']:
                    first_chat_name = current_update['message']['chat']['first_name']
                elif 'new_chat_member' in current_update['message']:
                    first_chat_name = current_update['message']['new_chat_member']['username']
                elif 'from' in current_update['message']:
                    first_chat_name = current_update['message']['from']['first_name']
                else:
                    first_chat_name = "unknown"
                
                if first_chat_text == "/togglestate":
                    sql = "SELECT activate FROM settings WHERE id = 1"
                    entry = db.select_one_row(sql)
                    new_offset = first_update_id + 1
                    if int(entry[0]) == 0:
                        print(first_chat_id)
                        sql = "UPDATE `settings` SET `activate` = '1' WHERE (`id` = '1');"
                        db.insert_update(sql)
                        iot_bot.send_message(first_chat_id, "Surveillance System Activated.")
                    else:
                        sql = "UPDATE `settings` SET `activate` = '0' WHERE (`id` = '1');"
                        db.insert_update(sql)
                        iot_bot.send_message(first_chat_id, "Surveillance System Disabled.")
                elif first_chat_text == "/website":
                    new_offset = first_update_id + 1
                    iot_bot.send_message(first_chat_id, website)
                elif first_chat_text == "/subscribe":
                    new_offset = first_update_id + 1
                    iot_bot.send_message(first_chat_id, subscribe(first_chat_id))
                elif first_chat_text == "/unsubscribe":
                    new_offset = first_update_id + 1
                    iot_bot.send_message(first_chat_id, unsubscribe(first_chat_id))
if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        db.close()
        exit()
