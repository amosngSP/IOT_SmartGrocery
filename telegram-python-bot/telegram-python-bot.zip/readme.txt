Code from: https://github.com/magnitopic/YouTubeCode
Setup:
1. Go to Telegram, open a chat with BotFather and create a bot. Remember to get your token.
2. Open up bothandler.py and insert your token there.
Notes:
1. api.py contains the python code to connect with the database. You might need to edit this to your liking.
2. The main code is in telegram_app.py